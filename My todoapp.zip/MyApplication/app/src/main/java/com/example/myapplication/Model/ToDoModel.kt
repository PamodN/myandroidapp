class ToDoModel {
    var id: Int = 0
        internal set
    var status: Int = 0
        internal set
    var task: String = ""
        internal set
}
